#include <iostream>
using namespace std;

// ��������� 
void myFunc();
void myFuncNext();

int main() {
	myFunc(); // myFunc
	myFuncNext(); // myFuncNext
	return 0;
}

// �����
void myFunc() {
	cout << "MyFunc\n";
}

void myFuncNext() {
	cout << "MyFuncNext\n";
}